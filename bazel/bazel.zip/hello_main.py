import hello_lib
hello_lib.print_hello_world()